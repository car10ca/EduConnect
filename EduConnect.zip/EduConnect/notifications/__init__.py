# Specifies the default configuration class for the notifications app
default_app_config = 'notifications.apps.NotificationsConfig'
